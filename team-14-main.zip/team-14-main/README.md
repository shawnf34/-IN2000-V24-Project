# team-14
Appen er dokumentert med kommentarer over funksjonene.

Appen kan installeres ved å laste ned ZIP filen og unzippe den. For å åpne den kan man åpne den i android studio, bygge den og så kjøre den. Man kan også laste den ned på en fysisk Android enhet.

Liste over eksterne biblioteker som er brukt: 
Ktor (versjon 2.3.8) Brukes for å deseralisere JSON filer til dataobjekter
Room (versjon 2.6.1) Brukes for å lage en SQLite database
Mapbox (Versjon 11.3.1) Brukes for kartfunksjonalitet i appen
Google location ( version 21.2.0) Brukes for å hente brukerlokasjon

