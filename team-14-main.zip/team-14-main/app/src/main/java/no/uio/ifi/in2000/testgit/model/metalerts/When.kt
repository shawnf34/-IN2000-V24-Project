package com.example.example

import com.google.gson.annotations.SerializedName


data class When (

  @SerializedName("interval" ) val interval : List<String>

)