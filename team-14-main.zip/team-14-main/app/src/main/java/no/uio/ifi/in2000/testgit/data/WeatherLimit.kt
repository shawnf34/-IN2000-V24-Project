package no.uio.ifi.in2000.testgit.data

data class WeatherLimit(val range: ClosedFloatingPointRange<Double>, val value: Double)